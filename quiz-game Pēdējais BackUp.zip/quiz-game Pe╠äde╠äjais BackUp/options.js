
const popUpWindow = document.querySelector("#popUp")
const topicElemement = document.querySelector("#topic")
const pointsElemement = document.querySelector("#points")
const questionElemement = document.querySelector("#question")
const choicesElement = document.querySelector("#choices")

// FETCH DATA FROM JSON
let quizData
async function getQuestions() {
  const response = await fetch("./questions.json")
  quizData = await response.json()
}
getQuestions().then(() => {
  loadAllQuestions()
}) // CALL THE FUNCTION TO RETRIEVE THE DATA


const closePopUp = document.getElementById("close-btn")
closePopUp.addEventListener("click", closePU)

function loadQuestionInToPopUp(questionObject) {
  // console.log(questionObject);
  popUpWindow.classList.remove("hidden")
  console.log(choiceBtnContainer);

  const choices = questionObject.choices
  topicElemement.innerHTML = questionObject.topic
  pointsElemement.innerHTML = questionObject.points + " " + "Points"
  questionElemement.innerHTML = questionObject.question
  const choiceBtnContainer = popUpWindow.querySelector(".choice-btn")
  for (const choices of Object.values(choices)) {
    const options = document.createElement("div")
    const optionBtn = document.createElement("button")
    optionBtn.innerHTML = choices
    options.classList.add("answer")
    choiceBtnContainer.appendChild(options)
    options.appendChild(optionBtn)

  }


  // for (const choice in choices) {
  //   console.log(choice);
  //   const options = document.createElement("div")
  //   const optionBtn = document.createElement("button")
  //   optionBtn.innerHTML = choice
  //   options.classList.add("answer")
  //   document.querySelector(".choice-btn").appendChild(options)
  //   options.appendChild(optionBtn)
  // }
}

function loadAllQuestions() {
  for (const category in quizData) {
    for (const questionObject in quizData[category]) {
      const currentQuestion = quizData[category][questionObject]
      const card = document.createElement("div");
      const questionTitle = document.createElement("p");
      questionTitle.innerHTML = currentQuestion.question
      card.classList.add("flip-card")
      document.querySelector(".main-grid").appendChild(card)
      card.appendChild(questionTitle)

      card.addEventListener("click", () => {
        loadQuestionInToPopUp(currentQuestion)
      })
    }
  }
}

function closePU() {
  popUpWindow.classList.add("hidden")
}

// ================================================================================

// const popUpWindow = document.querySelector("#popUp")
// const topicElemement = document.querySelector("#topic")
// const pointsElemement = document.querySelector("#points")
// const questionElemement = document.querySelector("#question")
// const choicesElement = document.querySelector("#choices")

// // FETCH DATA FROM JSON
// let quizData
// async function getQuestions() {
//   const response = await fetch("./questions.json")
//   quizData = await response.json()
// }
// getQuestions().then(() => {
//   loadAllQuestions()
// }) // CALL THE FUNCTION TO RETRIEVE THE DATA


// const closePopUp = document.getElementById("close-btn")
// closePopUp.addEventListener("click", closePU)

// function loadQuestionInToPopUp(questionObject) {
//   // console.log(questionObject);
//   popUpWindow.classList.remove("hidden")
//   console.log(choiceBtnContainer); // log the value of choiceBtnContainer

//   const choices = questionObject.choices
//   topicElemement.innerHTML = questionObject.topic
//   pointsElemement.innerHTML = questionObject.points + " " + "Points"
//   questionElemement.innerHTML = questionObject.question
//   const choiceBtnContainer = popUpWindow.querySelector(".choice-btn");
//   for (const choice of Object.values(choices)) {
//     const options = document.createElement("div")
//     const optionBtn = document.createElement("button")
//     optionBtn.innerHTML = choice
//     options.classList.add("answer")
//     choiceBtnContainer.appendChild(options)
//     options.appendChild(optionBtn)
//   }
// }

// function loadAllQuestions() {
//   for (const category in quizData) {
//     for (const questionObject in quizData[category]) {
//       const currentQuestion = quizData[category][questionObject]
//       const card = document.createElement("div");
//       const questionTitle = document.createElement("p");
//       questionTitle.innerHTML = currentQuestion.question
//       card.classList.add("flip-card")
//       document.querySelector(".main-grid").appendChild(card)
//       card.appendChild(questionTitle)

//       card.addEventListener("click", () => {
//         loadQuestionInToPopUp(currentQuestion)
//       })
//     }
//   }
// }

// function closePU() {
//   popUpWindow.classList.add("hidden")
// }