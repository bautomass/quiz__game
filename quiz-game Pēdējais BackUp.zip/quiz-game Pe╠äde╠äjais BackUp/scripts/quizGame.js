//FUNCTION TO MAKE APP LAYOUT WITH SIMPLE GRID
function quizGameTitles(subject1, subject2, subject3, subject4, subject5, subject6) {
    class AppLayoutTop {
      constructor(subject1, subject2, subject3, subject4, subject5, subject6) {
        this.subject1 = subject1
        this.subject2 = subject2
        this.subject3 = subject3
        this.subject4 = subject4
        this.subject5 = subject5
        this.subject6 = subject6
      }
  // GENERATES HTML FOR TOP SECTION IN THE APP //...LIMITĒT GRID TITLE RINDAS AR FOR LOOP MAYBE?
      generateTop() {
        const gameTop = `
        <div class="overlay">
        <div class="game-wrapper">
            <h1 class="game-name">Zināšanu Cīņas<br>
            </h1>
        </div>
        <div class="scoreTable">
          <div class="teamOne">
            <p id="teamOneScore">TEAM 
              <span>🟢</span>
                <span class="updateScoreT1" id="updateScoreT1"></span>
            </p>
          </div>
          <div class="teamsVs">
            <img src="/vs.png" alt="" srcset="" style="width: 80px;">
          </div>
          <div class="teamTwo">
            <p id="teamTwoScore">TEAM 
              <span>🔵</span>
              <span class="updateScoreT2" id="updateScoreT2"></span>
            </p>
          </div>
        </div>
        <div class="main-grid">
          <div class="grid--title">${this.subject1}</div>
          <div class="grid--title">${this.subject2}</div>
          <div class="grid--title">${this.subject3}</div>
          <div class="grid--title">${this.subject4}</div>
          <div class="grid--title">${this.subject5}</div>
          <div class="grid--title">${this.subject6}</div>
        </div>
      `
  // CREATES NEW DIV TO PLACE THE HTML IN IT
  const showGame = document.createElement("div")
  showGame.innerHTML = gameTop
  document.getElementById("quiz-game-top").appendChild(showGame)
      }
    }
  // NEW CLASS VARIABLE TO ADD GENERATETOP METHOD LATER
  const newAppLayoutTop = new AppLayoutTop(subject1, subject2, subject3, subject4, subject5, subject6)
  // ADDING GENERATETOP METHOD TO THE APPLAYOUTTOP CLASS
  newAppLayoutTop.generateTop()
  }
  // GEN ALL TITLES FOR EVERY SUBJECT IN GAME - CREATES HTML
  quizGameTitles("Ģeogrāfija", "Dziesmas", "Aktieri", "Mūziķi", "Dzīvnieki", "Cilvēki")
  
  //FUNCTION TO GENERATE CARDS BASED ON 2 PARAMETERS - DISPLAY IT IN THE DOCUMENT
  function quizGameCards(subject, points) {
    class AppLayoutBottom {
      constructor(subject, points) {
        this.subject = subject
        this.points = points

      }
  
      // GENERATES HTML FOR QUESTION CARDS IN THE GRID
      generateBottom() {
        const gameBottom = `
          <div class="flip-card" onclick="theQuestion()">
            <div class="flip-card-inner">
              <div class="flip-card-front">${this.points}</div>
              <div class="flip-card-back">
                <h1>${this.subject}</h1> 
                <p class="points">${this.points} Punkti</p> 
                <p class="question">JAUTĀJUMS</p>
              </div>
            </div>
          </div>
        `
        // CREATES NEW DIV TO PLACE THE HTML IN IT
        const showCards = document.createElement("div")
        showCards.classList.add("question-card")
        showCards.innerHTML = gameBottom
    
        document.querySelector(".main-grid").appendChild(showCards)
      }
    }
  
    // NEW CLASS VARIABLE TO ADD GENERATEBOTTOM METHOD LATER
    const newAppLayoutBottom = new AppLayoutBottom(subject, points)
    // ADDING GENERATEBOTTOM METHOD TO THE APPLAYOUTBOTTOM CLASS
    newAppLayoutBottom.generateBottom() 
  }
  
  
  const subjects = ["Ģeogrāfija", "Dziesmas", "Aktieri", "Mūziķi", "Dzīvnieki", "Cilvēki"];
  const points = ["200", "400", "600", "800", "1000"];


    for (let i = 0; i < subjects.length; i++) {
      for (let j = 0; j < points.length; j++) {
        quizGameCards(subjects[i], points[j]);
      }
    }

  let closeBtn = document.getElementById("close-btn")
  let popUpWindow = document.querySelector("#popUp")
  let topicElemement = document.querySelector("#topic")
  let pointsElemement = document.querySelector("#points")
  let questionElemement = document.querySelector("#question")
  let choice1 = document.querySelector("#answerBtn1")
  let choice2 = document.querySelector("#answerBtn2")
  let choice3 = document.querySelector("#answerBtn3")
  let btnAnswer = document.querySelectorAll(".answer")

 const questions = [
    {
        "topic": "Ģeogrāfija",
        "points": "200",
        "question": "Kura ir Francijas Galvas Pilsēta?",
        "choices": ["Parīze", "Berlīne", "Madride"],
        "answer": "Parīze"
    },
    {
        "topic": "Ģeogrāfija",
        "points": "400",
        "question": "Kura Ir Vecākā Pilsēta Latvijā?",
        "choices": ["Ludza", "Valmiera", "Cēsis"],
        "answer": "Ludza"
    },
    {
        "topic": "Ģeogrāfija",
        "points": "600",
        "question": "Kurš Ir Lielākais Kontinents?",
        "choices": ["Āfrika", "Āzija", "Austrālija"],
        "answer": "Āzija"
    },
    {
        "topic": "Ģeogrāfija",
        "points": "800",
        "question": "Garākā Upe Āfrikā?",
        "choices": ["Zambezi", "Kongo", "Nīla"],
        "answer": "Nīla"
    },
    {
        "topic": "Ģeogrāfija",
        "points": "1000",
        "question": "Pasaulē Vismazāk Apdzīvotā Pilsēta?",
        "choices": ["Parīze", "Berlīne", "Madride"],
        "answer": "Ngerulmuda"
    },
    {
        "topic": "Dziesmas",
        "points": "200",
        "question": "Kā sauc Latvijas Himnas Autoru?",
        "choices": ["Kalniņš Imants", "Kalniņš Alfrēds", "Baumaņu Kārlis"],
        "answer": "Baumaņu Kārlis"
    },
    {
        "topic": "Dziesmas",
        "points": "400",
        "question": "Kurš Ir Populārākais Mūzikas Novirziens Pasaulē?",
        "choices": ["Roks", "Hip-Hop/Rap", "Pop"],
        "answer": "Pop"
    },
    {
        "topic": "Dziesmas",
        "points": "600",
        "question": "Kurš No Šiem Singliem Ir Vispopulārākais Singls Jebkad?",
        "choices": ["Ed Sheeran - Shape of You", "Queen - Bohemian Rhapsody", "Michael Jackson - Billie Jean"],
        "answer": "Michael Jackson - Billie Jean"
    },
    {
        "topic": "Dziesmas",
        "points": "800",
        "question": "Kura Dziesma Ieguva 2020 Grammy Balvu Kā Song Of The Year?",
        "choices": ["Billie Eilish - Bad Guy", "Lewis Capaldi - Someone You Loved", "Lil Nas X ft. Billy Ray Cyrus - Old Town Road"],
        "answer": "Billie Eilish - Bad Guy"
    },
    {
        "topic": "Dziesmas",
        "points": "1000",
        "question": "Kurš Ir Dziesmas Work Hard Play Hard Autors?",
        "choices": ["Dr. Dre", "Wiz Khalifa", "2Pac"],
        "answer": "Wiz Khalifa"
    },
    {
        "topic": "Aktieri",
        "points": "200",
        "question": "Galvenās Lomas Atveidotājs Filmā Titāniks?",
        "choices": ["Steven Seagal", "Leonardo Di Kaprio", "Rowan Atkinson"],
        "answer": "Leonardo Di Kaprio"
    },
    {
        "topic": "Aktieri",
        "points": "400",
        "question": "Kurš Ieguva Labākā Aktiera Titulu 2022 Gadā?",
        "choices": ["Anthony Hopkins", "Gary Oldman", "Tom Hanks"],
        "answer": "Anthony Hopkins"
    },
    {
        "topic": "Aktieri",
        "points": "600",
        "question": "Kurš Ieguva Oskara Balvu Kā Labākais Aktieris Filmā The Godfather?",
        "choices": ["Marlon Brando", "Al Pacino", "Robert De Niro"],
        "answer": "Robert De Niro"
    },
    {
        "topic": "Aktieri",
        "points": "800",
        "question": "Kurš Aktieris Attēloja Indiana Jones Galveno Lomu?",
        "choices": ["Tom Cruise", "Sean Connery", "Harrison Ford"],
        "answer": "Harrison Ford"
    },
    {
        "topic": "Aktieri",
        "points": "1000",
        "question": "Kura Aktiere Atveidoja Moniku Seriālā Sirds Mīļā Monika?",
        "choices": ["Rēzija Kalniņa", "Mirdza Martinsone", "Dārta Daneviča"],
        "answer": "Mirdza Martinsone"
    },
    {
        "topic": "Mūziķi",
        "points": "200",
        "question": "Kādu Instrumentu Spēlē Ģitārists?",
        "choices": ["Klavieres", "Bungas", "Ģitāru"],
        "answer": "Ģitāru"
    },
    {
        "topic": "Mūziķi",
        "points": "400",
        "question": "Kura Māksliniece Ir Zināma Kā Queen Of Pop?",
        "choices": ["Madonna", "Mariah Carey", "Whitney Houston"],
        "answer": "Madonna"
    },
    {
        "topic": "Mūziķi",
        "points": "600",
        "question": "Kurš Ir Lead Singer Grupā Queen?",
        "choices": ["Freddie Starr", "Elvis Presley", "Freddie Mercury"],
        "answer": "Freddie Mercury"
    },
    {
        "topic": "Mūziķi",
        "points": "800",
        "question": "Kurš Ir Lead Singer Grupā The Rolling Stones?",
        "choices": ["Steven Tyler", "Freddie Mercury", "Mick Jagger"],
        "answer": "Mick Jagger"
    },
    {
        "topic": "Mūziķi",
        "points": "1000",
        "question": "Kura Ir Vispopulārākā Elvis Presley Dziesma?",
        "choices": ["If I Can Dream", "Always On My Mind", "Cant Help Falling In Love"],
        "answer": "Cant Help Falling In Love"
    },
    {
        "topic": "Dzīvnieki",
        "points": "200",
        "question": "Kuram Dzīvniekam Ir garš kakls un Plankumi?",
        "choices": ["Žirafe", "Zebra", "Zīlonis"],
        "answer": "Žirafe"
    },
    {
        "topic": "Dzīvnieki",
        "points": "400",
        "question": "Lielākais Zīdītājs Uz Zemes?'",
        "choices": ["Nīlszirgs", "Grizlij Lācis", "Āfrikas Zīlonis"],
        "answer": "Āfrikas Zīlonis"
    },
    {
        "topic": "Dzīvnieki",
        "points": "600",
        "question": "Kurš Ir Ātrākais Dzīvnieks uz Zemes?",
        "choices": ["Gepards", "Leopards", "Lauva"],
        "answer": "Gepards"
    },
    {
        "topic": "Dzīvnieki",
        "points": "800",
        "question": "Kura No Šīm Zivīm Ir Zivs?",
        "choices": ["Zobenzivs", "Medūza", "Jūras Zvaigzne"],
        "answer": "Zobenzivs"
    },
    {
        "topic": "Dzīvnieki",
        "points": "1000",
        "question": "Kā Dēvē Daudz Flamingi Vienu Viet (Bars Ar Flamingo)?",
        "choices": ["Ganāmpulks", "Spiets", "Kolonija"],
        "answer": "Kolonija"
    },
    {
        "topic": "Cilvēki",
        "points": "200",
        "question": "Kura Ķermeņa Daļa Tiek Izmantota Ožai?",
        "choices": ["Deguns", "Ausis", "Kājas"],
        "answer": "Deguns"
    },
    {
        "topic": "Cilvēki",
        "points": "400",
        "question": "Kurš Ir Lielākais Orgāns Cilvēka Ķermenī?",
        "choices": ["Aknas", "Plaušas", "Āda"],
        "answer": "Āda"
    },
    {
        "topic": "Cilvēki",
        "points": "600",
        "question": "Kurš Ir Garākais Kauls Cilvēka Ķermenī?",
        "choices": ["Stilba kauls (Tibia)", "Augšdelma kauls (Humerus)", "Ciskas kauls (Femur)"],
        "answer": "Ciskas kauls (Femur)"
    },
    {
        "topic": "Cilvēki",
        "points": "800",
        "question": "Jūtīgākais Cilvēka Orgāns?",
        "choices": ["Deguns", "Āda", "Acis"],
        "answer": "Āda"
    },
    {
        "topic": "Cilvēki",
        "points": "1000",
        "question": "Cik % No Kopējiem Skābekļa Un Asins Resursiem Patērē Smadzenes?",
        "choices": ["25%", "20%", "17%"],
        "answer": "20%"
    }
]

let currentQuestionIndex = 0
function theQuestion() {
  popUpWindow.classList.remove("hidden");
  questionElemement.innerHTML = questions[currentQuestionIndex].question;
  choice1.innerHTML = questions[currentQuestionIndex].choices[0];
  choice2.innerHTML = questions[currentQuestionIndex].choices[1];
  choice3.innerHTML = questions[currentQuestionIndex].choices[2];
  currentQuestionIndex++;
  if (currentQuestionIndex >= questions.length) { // reset index if end of array is reached
    currentQuestionIndex = 0;
  }
  btnAnswer.forEach(button => {
    button.addEventListener("click", checkAnswer)
  })
  function checkAnswer(){
    if(btnAnswer.innerHTML == questions[currentQuestionIndex].answer.innerHTML) {
      console.log(questions[currentQuestionIndex].answer);
      console.log("Jūs Atbildējāt Pareizi!");
    } else {
      console.log("Jūs Atbildējāt Nepareizi!");
    }
  }
}
function closePopUp() {
  popUpWindow.classList.add("hidden");
}












// btnAnswer.forEach(button => {
//   button.addEventListener("click", checkAnswer)
// })
// function checkAnswer(){
//   const btnValue = this.innerHTML
//   if(btnValue === quizData[key][keyValue]['answer']) {
//     console.log("Jūs Atbildējāt Pareizi!");
//   } else {
//     console.log("Jūs Atbildējāt Nepareizi!");
//   }
// }

// btnAnswer.forEach(button => {
  //           button.addEventListener("click", checkAnswer)
  //         })
  //         function checkAnswer() {
  //           const btnValue = this.innerHTML;
  //           if(btnValue === quizData[key][keyValue]['answer']) {
  //             console.log("Jūs Atbildējāt Pareizi!");
  //           } else {
  //             console.log("Jūs Atbildējāt Nepareizi!");
  //           }



////////////////////////////////////////////////////////////////
// function theQuestion() {
//   popUpWindow.classList.remove("hidden")
//   for (let i = 0; i < questions.length; i++){
//     // console.log(questions[0].topic, questions[0].question);
//     questionElemement.innerHTML = questions[0].question;
//     choice1.innerHTML = questions[0].choices[0];
//     choice2.innerHTML = questions[0].choices[1];
//     choice3.innerHTML = questions[0].choices[2];
//     // questionElemement.innerHTML = questions[1].question;
//   }
// }
// function closePopUp() {
//   popUpWindow.classList.add("hidden")
// }
////////////////////////////////////////////////////////////

  //FUNCTION TO GET ALL DATA FROM JSON
  // let quizData
  // async function getQuestions() {
  //   const response = await fetch("./questions.json")
  //   quizData = await response.json()
  // }
  // getQuestions() 

//   function theQuestion() {
//     popUpWindow.classList.remove("hidden")
//     for ( const key in quizData) {
//       for ( const keyValue in quizData[key]) {
//         console.log(quizData[key][keyValue]);
//         questionElemement.innerHTML = quizData[key][keyValue]['question']
//         choice1.innerHTML = quizData[key][keyValue]['choices'][0]
//         choice2.innerHTML = quizData[key][keyValue]['choices'][1]
//         choice3.innerHTML = quizData[key][keyValue]['choices'][2]

        
//         btnAnswer.forEach(button => {
//           button.addEventListener("click", checkAnswer)
//         })
//         function checkAnswer() {
//           const btnValue = this.innerHTML;
//           if(btnValue === quizData[key][keyValue]['answer']) {
//             console.log("Jūs Atbildējāt Pareizi!");
//           } else {
//             console.log("Jūs Atbildējāt Nepareizi!");
//           }
//         }
//       }
//     }
//   }
  
// function closePopUp() {
//   popUpWindow.classList.add("hidden")
// }


