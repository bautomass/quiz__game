// import all questions from json

// generate cards based on all questions in all categories

// for loop
// function generateCard

// generateCard
// addEventListner to Button, attach function pickQuestion/ShowQuestionPopUp

// pickQuestion(questionObj)
// show question pop up
// fill it in with all relevant data (this.topic, etc)
// foreach choices
// addEventListner to each choice with attached testAnswer or immidiate function

// testAnswer(chosenAnswer, rightAnswer)